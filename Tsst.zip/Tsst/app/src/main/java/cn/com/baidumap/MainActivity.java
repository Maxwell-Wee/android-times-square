package cn.com.baidumap;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.BMapManager;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.MapView;

import cn.com.tsst.R;

public class MainActivity extends Activity {

    public MyLocationListenner myListener = new MyLocationListenner();
    // 定位相关
    LocationClient mLocClient;


    private Button btnMap;
    MapView mMapView = null;
    TextView LocationResult;

    BMapManager mBMapMan = null;

    private boolean isReturnLocationData = false;
    private static final String LTAG = MainActivity.class.getSimpleName();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mBMapMan = new BMapManager();
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.activity_main);
        mMapView = (MapView) findViewById(R.id.bmapView);


        LocationResult = (TextView) findViewById(R.id.btn_location);
        LocationResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, LocationDemo.class);
                startActivity(intent);

            }
        });

        btnMap = (Button) findViewById(R.id.btn_map);
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, OverlayDemo.class);
                startActivity(intent);
            }
        });

//        turnGPSOn();


        //  GPS定位
        gpsLocation();


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isReturnLocationData) {
                    Log.e("已经返回经纬度", "  ＝＝＝＝＝＝＝＝＝");
                } else {
                    YesNoDialog dialog = new YesNoDialog(MainActivity.this, R.style.class_dialog,
                            YesNoDialog.ALERT_DELETE, "取消请求", "设置", "是否进入设置界面来管理定位权限", new YesNoDialog.DialogListener() {
                        @Override
                        public void onConfirm() {
                            Intent intent =  new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivity(intent);
                        }

                        @Override
                        public void onCancel() {

                        }
                    });
                    dialog.show();
                }
            }
        }, 5000);

    }





    private void gpsLocation() {
        Log.e("开始获取定位", "");
        // 定位初始化
        mLocClient = new LocationClient(this);
        mLocClient.registerLocationListener(myListener);
        LocationClientOption option = new LocationClientOption();
        option.setOpenGps(true); // 打开gps

        option.setCoorType("bd09ll"); // 设置坐标类型
        option.setScanSpan(1000);
        mLocClient.setLocOption(option);
        mLocClient.start();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，实现地图生命周期管理
        mMapView.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
        mMapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
        mMapView.onPause();
    }


    /**
     * 定位SDK监听函数
     */
    public class MyLocationListenner implements BDLocationListener {

        @Override
        public void onReceiveLocation(BDLocation location) {
            Log.e("经纬度======", "经度:" + location.getLatitude() + "  纬度" + location.getLongitude());
            isReturnLocationData = true;

        }

        public void onReceivePoi(BDLocation poiLocation) {
        }
    }



    public void turnGPSOn()
    {
        Intent intent = new Intent("android.location.GPS_ENABLED_CHANGE");
        intent.putExtra("enabled", true);
        this.sendBroadcast(intent);

        String provider = Settings.Secure.getString(getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
        if(!provider.contains("gps")){ //if gps is disabled
            final Intent poke = new Intent();
            poke.setClassName("com.android.settings", "com.android.settings.widget.SettingsAppWidgetProvider");
            poke.addCategory(Intent.CATEGORY_ALTERNATIVE);
            poke.setData(Uri.parse("3"));
            this.sendBroadcast(poke);
        }
    }



}
